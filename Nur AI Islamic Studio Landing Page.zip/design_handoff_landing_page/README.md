# Handoff: Nur AI Landing Page

## Overview
Marketing landing page for Nur AI, an AI content studio serving Islamic brands and Muslim creators. Sections: nav, hero, three-agent showcase (Maryam/Aisha/Ahmad), process steps, featured work, client logos, final CTA, footer.

## About the Design Files
The bundled file (`Nur AI Landing.dc.html`) is a **design reference built in an internal prototyping format** (custom template tags like `<sc-for>`, `<image-slot>`) — it is not production code to copy directly. Recreate this design in your target stack (React/Vue/plain HTML — whichever your codebase uses) using its existing component and styling conventions. Treat this as the visual/interaction spec.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and copy are intended as final; recreate pixel-close.

## Design Tokens
- Background (deep green): `#0c281f`, panel green `#102e24` / `#0a2018`
- Gold accent: `#c9a961`, gold light: `#e3cd8a`
- Text: cream `#f6f1e6`, muted `rgba(246,241,230,0.7 / 0.5 / 0.45)`
- Borders/dividers: `rgba(201,169,97,0.14–0.24)`
- Headings font: "Cormorant Garamond" (serif, weights 400/500/600, italic for accents)
- Body font: "Manrope" (400/500/600/700)
- Border-radius: mostly 2px (buttons, images) — sharp/elegant, not rounded
- Section padding: fluid via `clamp()`, roughly 60–140px vertical depending on viewport

## Screens / Sections

### Nav
Sticky, translucent dark-green background with blur, gold-bottom hairline border. Left: logo mark (circle outline "ن" + "Nur AI" in Cormorant Garamond). Right: nav links (Agents/Process/Work) + gold gradient "Book a Call" button (mailto link). Wraps on narrow viewports (no hamburger — flex-wrap).

### Hero
Full-bleed background image (user-supplied cinematic travel still) with dark green gradient scrim + soft gold radial glow. Centered content: gold eyebrow label with flanking rules, large serif headline "Turn Cinematic / *Travel.*" (italic gold accent on second word), subhead copy, two CTAs (solid gold "Book a Call", outlined "See the Work").

### Three Agents (`#agents`)
Section heading + intro. 3-column grid (auto-fit, min 280px), 1px gold-tinted divider lines between cards. Each card: gold-outlined circle monogram (Arabic initial), name (serif) + role label (small caps gold), description paragraph, italicized quote line with top divider.
Content:
- **Maryam** — Strategist & Orchestrator — owns strategy/direction/delegation. Quote: "Every piece starts with why."
- **Aisha** — Guide & Outreach — location scouting, logistics, permits, light. Quote: "The location is half the story."
- **Ahmad** — Audio & Final Polish — nasheed matching, caption timing, final QA gate. Quote: "Precision, not impressions."

### Process (`#process`)
Darker panel section, top/bottom hairline borders. 4-column grid (auto-fit, min 220px), each item has a gold top border, small serif step number (01–04), bold title, description. Steps: Strategy → Research & Logistics → Production → Audio & Polish.

### Featured Work (`#work`)
Header row: "Featured Work" eyebrow + "@baxxthobes" serif title, right-aligned supporting copy. 3-column image grid (fixed aspect via clamp height), placeholders for real stills.

### Logos
Small eyebrow label, 5-column responsive grid of logo image placeholders (contain-fit, 56px height), 85% opacity.

### Final CTA
Full-width rounded panel (radial gold/green gradient glow, gold border), centered serif headline "Let's tell your story.", supporting copy, single gold gradient "Book a Call" button.

### Footer
Logo mark, copyright line, Instagram/Email links. Flex row, wraps on mobile.

## Interactions & Behavior
- All CTA "Book a Call" buttons → `mailto:hello@nurai.studio?subject=Book%20a%20Call` (placeholder — wire to real booking flow, e.g. Calendly).
- Buttons/links have hover states: opacity dim on gold buttons, color shift to gold on outlined/text links.
- No JS-driven interactivity beyond hover — layout is achieved with CSS Grid `auto-fit`/`minmax` and `clamp()` fluid sizing, so it reflows continuously without breakpoints.
- Fully responsive by construction (fluid typography/spacing, wrapping flex/grid) — no fixed breakpoints to replicate, just keep the same fluid approach or convert to your breakpoint system.

## Assets
- Hero background, 3 work images, 5 logos are **empty placeholders** (drag-and-drop slots in the prototype) — real photography/logos need to be sourced and dropped in before production use.
- "ن" glyph used as a simple text monogram, not an image asset.

## Files
- `Nur AI Landing.dc.html` — full design reference (all sections, inline styles)
- `image-slot.js` — placeholder-image web component used only in the prototype tool; not needed in production (replace with real `<img>`/asset pipeline)
